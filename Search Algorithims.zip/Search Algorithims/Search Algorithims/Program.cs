﻿int[] arr = { 1, 9, 17, 30, 67, 90 };
int findNumber = 17;

int index = LinearSearch(arr, findNumber);
if (index != -1)
{
    Console.WriteLine($"Number {findNumber} found at index {index}.");
}
else
{
    Console.WriteLine($"Number {findNumber} not found in the array.");
}


static int LinearSearch(int[] arr, int findNumber)
{
    for (int i = 0; i < arr.Length; i++)
    {
        if (arr[i]==findNumber)
        {
            return i; // Return the index of the found number
        }
    }
    return -1; // Return -1 if the number is not found
}
  
static int BinarySearch(int[] arr,int findNumber)
{
    int low = 0, high = arr.Length - 1;

    while(low <= high)
    {
        int mid= (low + high) / 2;

        if (arr[mid]==findNumber)
        {
            return mid; // Return the index of the found number
        }
        else if (arr[mid] > findNumber)
        {
            high = mid - 1; // Search in the left half
        }
        else
        {
            low = mid + 1; // Search in the right half
        }
    }
    return -1; // Return -1 if the number is not found
}

int Binaryindex= BinarySearch(arr, findNumber);
if (index != -1)
{
    Console.WriteLine($"Number {findNumber} found at index {index}.");
}
else
{
    Console.WriteLine($"Number {findNumber} not found in the array.");
}